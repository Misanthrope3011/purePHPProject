$(document).ready(function()
{
    var listOfImages;
    var getIndex;
    
    
    if(sessionStorage.getItem('index')===null)
    getIndex=0;
    else
    getIndex=sessionStorage.getItem('index');

    
    if(JSON.parse(localStorage.getItem('images'))===null)
   { 
    listOfImages=[];
     } 
      else
   {
    listOfImages=JSON.parse(localStorage.getItem('images'));
   }

    var numberOfImagesInGalery;
    const maxNumberOfImages=5;
  

    var galeryItem= {};

   var galeryList=JSON.parse(localStorage.getItem('galeryItem'));
 
    
   if(galeryList===null)
    galeryList=[];
    else

    for (var i=0; i<galeryList.length;i++)
    { 
        $(".galeria").append( ('<div class="inner"> <a href="galeriaSlider.html" alt="galeria"> <img src="'+ listOfImages[galeryList[i].currentIndex-1]+'" alt="zdjecie"> </a>  <h3>' + galeryList[i].title +'</h3> </div>'));
    }

    var filesInput = $("#image");
    var lengthOfItemsInGalery=listOfImages.length;

    filesInput.on("change", function(e) {
        var files = e.target.files; 
      
        $.each(files, function(i, file) {
            listOfImages.push("photos/"+$("#image").prop('files')[i].name);
            localStorage.setItem('images',JSON.stringify(listOfImages));
        });
    });

    $("#createNew").click(function () {  
        galeryItem.title=$("#titleForGalery").val();
        galeryItem.numberOfImagesInGalery=listOfImages.length-lengthOfItemsInGalery;

    if(galeryList.length!=0)
        galeryItem.currentIndex=galeryList[galeryList.length-1].currentIndex+galeryItem.numberOfImagesInGalery;
    else
        galeryItem.currentIndex=galeryItem.numberOfImagesInGalery;
 
    galeryList.push(galeryItem);

    localStorage.setItem('galeryItem', JSON.stringify(galeryList));

    });
    

        $('.galeria').on('click', '.inner', function()
        {   
        getIndex=$('.inner').index(this);
        sessionStorage.setItem('index', getIndex);
        });

     
   if(listOfImages.length!=0)
    {
            if(getIndex!=0)
            {
             for (var i=galeryList[getIndex-1].currentIndex; i<galeryList[getIndex].currentIndex;i++)
                {
                    $("ul#galery").append('<li> <div class="content"> <img src='+listOfImages[i]+'> <h2> Zdjęcie'+((i%5)+1) +'</h2></div></li>');
                }
            }
            else
            {
                for (var i=0; i<galeryList[0].currentIndex;i++)
                {            
                    $("ul#galery").append('<li> <div class="content"> <img src='+ listOfImages[i]+'> <h2> Zdjęcie'+((i%5)+1) +'</h2></div></li>');
                }
            }
    }
 });

