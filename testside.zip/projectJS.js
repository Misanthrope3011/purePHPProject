function invalid ()
{
    window.open("rejestracja.html");
}

$(document).ready(function()
{

    $('#myModal').modal('hide');

    var getPage;
    var userList=JSON.parse(localStorage.getItem('dataUser'));
    var currentUser=JSON.parse(sessionStorage.getItem('currentUser'));

    var reverseCounter=true;

    if (retrieveItem!=null)
    retrieveItem.reverse();
    else
    retrieveItem=[];

    if(currentUser!=null)
    $("#userDisplayData").append((currentUser.name + "  "+currentUser.age +'<br/>' + '<button id="logOut"> Wyloguj </button> '  ));

    function displayList()
    {

        if(reverseCounter)
      {
        retrieveItem.reverse();
        reverseCounter=false;
      }  
        $("#articleContainer").empty();

        for (var i=temp;i<temp+numberOfItemsOnPage && i<(retrieveItem.length);i++)
        {
          $("#articleContainer").append(' <div class="post"><h3>'+ retrieveItem[i].title +' </h3>    <b> ' + retrieveItem[i].intro + '</b> <br/> <div id="imageGrid"> '+ retrieveItem[i].content +'   <img src="' + retrieveItem[i].image + '" alt="header">   </div>   <button class="delete"> x </button> <button class="edit"> E </button>    </div>  ');   
        }
   
    }
     
    
    if(sessionStorage.getItem('pageNumber')===null)
    { 
   
        getPage=0;
   
    }
     else
    {  
    getPage=parseInt(sessionStorage.getItem('pageNumber'));
    }

    var numberOfItemsOnPage=4;
    var replaceContent,numberOfPages;
    var retrieveItem = JSON.parse(localStorage.getItem('article'));

    var indexOfEdited=sessionStorage.getItem('indexOfEdited');

    if(indexOfEdited!=null)
    {
        
            $("#setTitle").prop("value", (retrieveItem[retrieveItem.length-1-indexOfEdited].title));
            $('#articleIntro').prop("value", (retrieveItem[retrieveItem.length-1-indexOfEdited].intro));
            $('#articleContent').prop("value", (retrieveItem[retrieveItem.length-1-indexOfEdited].content));
            $('#image').prop("placeholder", (retrieveItem[retrieveItem.length-1-indexOfEdited].image));
            $("#sendArticle2").text("edytuj");
    }   

    if(retrieveItem===null)
    retrieveItem=[];

    var deleteIndex;
    var temp=getPage*numberOfItemsOnPage;

        for(var i=1; (i<retrieveItem.length/numberOfItemsOnPage+1);i++)
        {
            $("#link").append('<a href="index.html" alt="strona">' + i +'</a>' );
        }

        displayList();
    
    
     numberOfPages=Math.ceil(retrieveItem.length%2);

     $('#articleContainer').on('click', '.delete', function()
     {   
      var temp=($(".delete").index(this));
      retrieveItem.splice(temp,1);
      localStorage.setItem('article', JSON.stringify(retrieveItem));

      displayList();
      
    });

    $('#userDisplayData').on('click', '#logOut', function()
    {   
     sessionStorage.removeItem('currentUser');
    location.reload();
   });

    $('#articleContainer').on('click', '.edit', function()
     {      
    var temp=($(".edit").index(this));
    sessionStorage.setItem('indexOfEdited', temp);
    $(location).prop('href', 'create.html');
    });
     
    $('#link').on('click', 'a', function(e)
    {   
     getPage=($(this).closest("a").index());
     JSON.stringify(sessionStorage.setItem('pageNumber', getPage));
    });
    
    $(".post").css("background-color", "white"); 

        $("#btn1").click(function(){
        $("h2").hide();
    });


$("#formSubmit").click(function(e)
{

if($("form[name='validate']").valid())
{
        user.email=$("#exampleInputEmail1").val();
        user.name=$("#nameAndSurname").val();
        user.age=$("#ageInputId").val();
        user.password=$("#exampleInputPassword1").val();
        user.hobby="";

        var unique=true;

        if($("#exampleCheck1").is(":checked"))
        {
         
           user.hobby+=$("#exampleCheck1").val() + " ";
        }
        if($("#exampleCheck2").is(":checked"))
        {
           user.hobby+=$("#exampleCheck2").val()  + " ";
        }
        if($("#exampleCheck3").is(":checked"))
        {
           user.hobby+=$("#exampleCheck3").val() + " ";
        }

        if (userList===null)
        userList=[];

        userList.push(user);
        localStorage.setItem('dataUser',JSON.stringify(userList));   
        
      }
      else
        e.preventDefault();
 
    });

   

    $("#sendArticle2").click(function(e)
    {
        retrieveItem = JSON.parse(localStorage.getItem('article'));

        var article={};
  
     
        if(indexOfEdited!=null)
        {
            retrieveItem[retrieveItem.length-1-indexOfEdited].title=$('#setTitle').val();
            retrieveItem[retrieveItem.length-1-indexOfEdited].intro=$('#articleIntro').val();
            retrieveItem[retrieveItem.length-1-indexOfEdited].content=$('#articleContent').val();
         
           if($("#image").val()!="")
            {
            retrieveItem[retrieveItem.length-1-indexOfEdited].image="photos/"+$("#image").prop('files')[0].name ;
            }
           sessionStorage.removeItem('indexOfEdited');
        }
        else
        {
            article.title = $('#setTitle').val();
            article.intro= $("#articleIntro").val();
            article.content=$('#articleContent').val();
            article.image="photos/"+$("#image").prop('files')[0].name;
        
            retrieveItem.push(article); 
        }
        
        localStorage.setItem('article', JSON.stringify(retrieveItem));   
        $(location).attr('href', 'index.html');

    });

    var user={};

    $("#logIn").click(function(e)
    {
        e.preventDefault();
        var tempName=$("#username").val();
        var tempPassword=$("#password").val();
        
      $.each(userList,function(i)
        {   
            if(tempName==userList[i].name && tempPassword==userList[i].password)
               { 
                sessionStorage.setItem('currentUser',JSON.stringify(userList[i]));
                return false;
               }

        });

        if(JSON.parse(sessionStorage.getItem('currentUser')===null))
       {
        $("#password, #username").css("border-color", "red");
        $(".modal-body").text( "Blędne dane lub użytkownik nie istnieje");
        $(".modal-footer .btn").addClass('btn-danger').removeClass('.btn btn-secondary, .btn btn-success');
       }
       else
       {
        $("#password, #username").css("border-color", "greenyelow");
        $(".modal-body").text( "Zalogowano pomyślnie");
        $(".modal-footer .btn").addClass('.btn-success').removeClass('.btn btn-secondary, .btn btn-danger');
       }

    $('#myModal').modal('show');


    });   
    
    $("#myModal").on("hidden.bs.modal", function () {
      if($(".modal-footer.btn").hasClass(".btn-success"))
      {
          (location).href('index.html');
        
      }
      else if ($(".modal-footer.btn").hasClass('.btn-danger'))
      {
        (location).href('rejestracja.html');

      }
    });

    $(document).on('click','#editAddArticleButton',function(){
        $this.val("hide"); //OR  $this.val("Hide") //if you are using input type="button"
    });
});





